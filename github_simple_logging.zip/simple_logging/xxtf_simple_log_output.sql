
drop table xxtf_simple_log_output;

create table xxtf_simple_log_output(
output varchar2(4000) not null
);

